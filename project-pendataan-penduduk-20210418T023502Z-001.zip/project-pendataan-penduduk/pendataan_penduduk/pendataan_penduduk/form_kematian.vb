﻿Imports MySql.Data.MySqlClient
Public Class form_kematian

    Private Sub form_kematian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call CenterToScreen()
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        tutup()
        tampilGrid()
        aturDGV()
    End Sub

    Sub tutup()
        ComboBox1.Enabled = False
        ComboBox2.Enabled = False
        ComboBox3.Enabled = False
        ComboBox4.Enabled = False
        ComboBox5.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        DateTimePicker1.Enabled = False
    End Sub
    Sub buka()
        ComboBox1.Enabled = True
        ComboBox2.Enabled = True
        ComboBox3.Enabled = True
        ComboBox4.Enabled = True
        ComboBox5.Enabled = True
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        DateTimePicker1.Enabled = True
        combo()
    End Sub
    Sub bersih()
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        ComboBox4.Text = ""
        ComboBox5.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        DateTimePicker1.Text = ""
    End Sub

    Sub combo()
        ComboBox2.Items.Add("Senin")
        ComboBox2.Items.Add("Selasa")
        ComboBox2.Items.Add("Rabu")
        ComboBox2.Items.Add("Kamis")
        ComboBox2.Items.Add("Jum'at")
        ComboBox2.Items.Add("Sabtu")
        ComboBox2.Items.Add("Minggu")
    End Sub
    Sub aturDGV()
        Try
            DataGrid_kematian.Columns(0).Width = 70
            DataGrid_kematian.Columns(1).Width = 150
            DataGrid_kematian.Columns(2).Width = 100
            DataGrid_kematian.Columns(3).Width = 100
            DataGrid_kematian.Columns(4).Width = 100
            DataGrid_kematian.Columns(5).Width = 100
            DataGrid_kematian.Columns(6).Width = 100
            DataGrid_kematian.Columns(7).Width = 100


            DataGrid_kematian.Columns(0).HeaderText = "NIK"
            DataGrid_kematian.Columns(1).HeaderText = "Nama"
            DataGrid_kematian.Columns(2).HeaderText = "Umur"
            DataGrid_kematian.Columns(3).HeaderText = "Hari"
            DataGrid_kematian.Columns(4).HeaderText = "Tanggal"
            DataGrid_kematian.Columns(5).HeaderText = "Tempat"
            DataGrid_kematian.Columns(6).HeaderText = "Sebab"
            DataGrid_kematian.Columns(7).HeaderText = "Yang Menentukan"

        Catch ex As Exception
        End Try
    End Sub

    Sub tampilGrid()
        Call koneksi()
        da = New MySqlDataAdapter("select nik, nama, umur, hari_meninggal, tgl_meninggal, tmp_meninggal, sebab_meninggal, yang_menentukan from tabel_kematian", conn)
        ds = New DataSet
        da.Fill(ds, "tabel_kematian")
        DataGrid_kematian.DataSource = ds.Tables("tabel_kematian")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        buka()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
End Class
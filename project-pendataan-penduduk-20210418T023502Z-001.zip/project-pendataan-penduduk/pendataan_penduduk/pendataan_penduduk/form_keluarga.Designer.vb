﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_keluarga
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_keluar = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_simpan = New System.Windows.Forms.Button()
        Me.btn_tambah = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.rtbox_ket = New System.Windows.Forms.RichTextBox()
        Me.lbl_ket = New System.Windows.Forms.Label()
        Me.rtbox_alamat = New System.Windows.Forms.RichTextBox()
        Me.lbl_alamat = New System.Windows.Forms.Label()
        Me.judul = New System.Windows.Forms.Label()
        Me.tbox_nama = New System.Windows.Forms.TextBox()
        Me.lbl_nama = New System.Windows.Forms.Label()
        Me.lbl_rtrw = New System.Windows.Forms.Label()
        Me.tbox_rtrw = New System.Windows.Forms.TextBox()
        Me.tbox_kdpos = New System.Windows.Forms.TextBox()
        Me.lbl_kdpos = New System.Windows.Forms.Label()
        Me.rtbox_almtlain = New System.Windows.Forms.RichTextBox()
        Me.lbl_almtlain = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_keluar
        '
        Me.btn_keluar.Location = New System.Drawing.Point(503, 498)
        Me.btn_keluar.Name = "btn_keluar"
        Me.btn_keluar.Size = New System.Drawing.Size(75, 23)
        Me.btn_keluar.TabIndex = 92
        Me.btn_keluar.Text = "keluar"
        Me.btn_keluar.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(400, 498)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 91
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_simpan
        '
        Me.btn_simpan.Location = New System.Drawing.Point(286, 498)
        Me.btn_simpan.Name = "btn_simpan"
        Me.btn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.btn_simpan.TabIndex = 90
        Me.btn_simpan.Text = "Simpan"
        Me.btn_simpan.UseVisualStyleBackColor = True
        '
        'btn_tambah
        '
        Me.btn_tambah.Location = New System.Drawing.Point(176, 498)
        Me.btn_tambah.Name = "btn_tambah"
        Me.btn_tambah.Size = New System.Drawing.Size(75, 23)
        Me.btn_tambah.TabIndex = 89
        Me.btn_tambah.Text = "Tambah"
        Me.btn_tambah.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(793, 143)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(510, 569)
        Me.DataGridView1.TabIndex = 88
        '
        'rtbox_ket
        '
        Me.rtbox_ket.Location = New System.Drawing.Point(189, 410)
        Me.rtbox_ket.Name = "rtbox_ket"
        Me.rtbox_ket.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_ket.TabIndex = 87
        Me.rtbox_ket.Text = ""
        '
        'lbl_ket
        '
        Me.lbl_ket.AutoSize = True
        Me.lbl_ket.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ket.Location = New System.Drawing.Point(41, 410)
        Me.lbl_ket.Name = "lbl_ket"
        Me.lbl_ket.Size = New System.Drawing.Size(62, 13)
        Me.lbl_ket.TabIndex = 86
        Me.lbl_ket.Text = "Keterangan"
        '
        'rtbox_alamat
        '
        Me.rtbox_alamat.Location = New System.Drawing.Point(189, 191)
        Me.rtbox_alamat.Name = "rtbox_alamat"
        Me.rtbox_alamat.Size = New System.Drawing.Size(448, 37)
        Me.rtbox_alamat.TabIndex = 83
        Me.rtbox_alamat.Text = ""
        '
        'lbl_alamat
        '
        Me.lbl_alamat.AutoSize = True
        Me.lbl_alamat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_alamat.Location = New System.Drawing.Point(41, 194)
        Me.lbl_alamat.Name = "lbl_alamat"
        Me.lbl_alamat.Size = New System.Drawing.Size(39, 13)
        Me.lbl_alamat.TabIndex = 82
        Me.lbl_alamat.Text = "Alamat"
        '
        'judul
        '
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(609, 29)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(269, 29)
        Me.judul.TabIndex = 79
        Me.judul.Text = "Pendataan Pendatang"
        '
        'tbox_nama
        '
        Me.tbox_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbox_nama.Location = New System.Drawing.Point(189, 143)
        Me.tbox_nama.Name = "tbox_nama"
        Me.tbox_nama.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nama.TabIndex = 96
        '
        'lbl_nama
        '
        Me.lbl_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(41, 150)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(116, 13)
        Me.lbl_nama.TabIndex = 95
        Me.lbl_nama.Text = "Nama Kepala Keluarga"
        '
        'lbl_rtrw
        '
        Me.lbl_rtrw.AutoSize = True
        Me.lbl_rtrw.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_rtrw.Location = New System.Drawing.Point(41, 250)
        Me.lbl_rtrw.Name = "lbl_rtrw"
        Me.lbl_rtrw.Size = New System.Drawing.Size(44, 13)
        Me.lbl_rtrw.TabIndex = 99
        Me.lbl_rtrw.Text = "RT RW"
        '
        'tbox_rtrw
        '
        Me.tbox_rtrw.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbox_rtrw.Location = New System.Drawing.Point(189, 247)
        Me.tbox_rtrw.Name = "tbox_rtrw"
        Me.tbox_rtrw.Size = New System.Drawing.Size(448, 20)
        Me.tbox_rtrw.TabIndex = 100
        '
        'tbox_kdpos
        '
        Me.tbox_kdpos.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbox_kdpos.Location = New System.Drawing.Point(189, 292)
        Me.tbox_kdpos.Name = "tbox_kdpos"
        Me.tbox_kdpos.Size = New System.Drawing.Size(448, 20)
        Me.tbox_kdpos.TabIndex = 102
        '
        'lbl_kdpos
        '
        Me.lbl_kdpos.AutoSize = True
        Me.lbl_kdpos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_kdpos.Location = New System.Drawing.Point(41, 295)
        Me.lbl_kdpos.Name = "lbl_kdpos"
        Me.lbl_kdpos.Size = New System.Drawing.Size(53, 13)
        Me.lbl_kdpos.TabIndex = 101
        Me.lbl_kdpos.Text = "Kode Pos"
        '
        'rtbox_almtlain
        '
        Me.rtbox_almtlain.Location = New System.Drawing.Point(189, 335)
        Me.rtbox_almtlain.Name = "rtbox_almtlain"
        Me.rtbox_almtlain.Size = New System.Drawing.Size(448, 37)
        Me.rtbox_almtlain.TabIndex = 104
        Me.rtbox_almtlain.Text = ""
        '
        'lbl_almtlain
        '
        Me.lbl_almtlain.AutoSize = True
        Me.lbl_almtlain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_almtlain.Location = New System.Drawing.Point(41, 338)
        Me.lbl_almtlain.Name = "lbl_almtlain"
        Me.lbl_almtlain.Size = New System.Drawing.Size(62, 13)
        Me.lbl_almtlain.TabIndex = 103
        Me.lbl_almtlain.Text = "Alamat Lain"
        '
        'form_keluarga
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.rtbox_almtlain)
        Me.Controls.Add(Me.lbl_almtlain)
        Me.Controls.Add(Me.tbox_kdpos)
        Me.Controls.Add(Me.lbl_kdpos)
        Me.Controls.Add(Me.tbox_rtrw)
        Me.Controls.Add(Me.lbl_rtrw)
        Me.Controls.Add(Me.tbox_nama)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.btn_keluar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btn_simpan)
        Me.Controls.Add(Me.btn_tambah)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.rtbox_ket)
        Me.Controls.Add(Me.lbl_ket)
        Me.Controls.Add(Me.rtbox_alamat)
        Me.Controls.Add(Me.lbl_alamat)
        Me.Controls.Add(Me.judul)
        Me.Name = "form_keluarga"
        Me.Text = "form_keluarga"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_keluar As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btn_simpan As System.Windows.Forms.Button
    Friend WithEvents btn_tambah As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents rtbox_ket As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_ket As System.Windows.Forms.Label
    Friend WithEvents rtbox_alamat As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_alamat As System.Windows.Forms.Label
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents tbox_nama As System.Windows.Forms.TextBox
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
    Friend WithEvents lbl_rtrw As System.Windows.Forms.Label
    Friend WithEvents tbox_rtrw As System.Windows.Forms.TextBox
    Friend WithEvents tbox_kdpos As System.Windows.Forms.TextBox
    Friend WithEvents lbl_kdpos As System.Windows.Forms.Label
    Friend WithEvents rtbox_almtlain As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_almtlain As System.Windows.Forms.Label
End Class

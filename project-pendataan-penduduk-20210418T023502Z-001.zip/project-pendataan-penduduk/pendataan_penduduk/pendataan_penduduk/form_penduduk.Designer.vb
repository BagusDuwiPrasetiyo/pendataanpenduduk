﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_penduduk
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lbl_nik = New System.Windows.Forms.Label()
        Me.lbl_nama = New System.Windows.Forms.Label()
        Me.lbl_tmptlahir = New System.Windows.Forms.Label()
        Me.lbl_tgllahir = New System.Windows.Forms.Label()
        Me.lbl_jk = New System.Windows.Forms.Label()
        Me.lbl_goldar = New System.Windows.Forms.Label()
        Me.lbl_alamat = New System.Windows.Forms.Label()
        Me.lbl_agama = New System.Windows.Forms.Label()
        Me.lbl_pddknter = New System.Windows.Forms.Label()
        Me.lbl_statuspddkn = New System.Windows.Forms.Label()
        Me.lbl_pekerjaan = New System.Windows.Forms.Label()
        Me.lbl_notelp = New System.Windows.Forms.Label()
        Me.lbl_statuskwn = New System.Windows.Forms.Label()
        Me.lbl_kwgnegara = New System.Windows.Forms.Label()
        Me.lbl_tglreg = New System.Windows.Forms.Label()
        Me.tbox_nik = New System.Windows.Forms.TextBox()
        Me.tbox_nama = New System.Windows.Forms.TextBox()
        Me.tbox_tmptlahir = New System.Windows.Forms.TextBox()
        Me.tgl_lahir = New System.Windows.Forms.DateTimePicker()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.judul = New System.Windows.Forms.Label()
        Me.combo_jk = New System.Windows.Forms.ComboBox()
        Me.combo_gd = New System.Windows.Forms.ComboBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_keluar = New System.Windows.Forms.Button()
        Me.btnkeluar = New System.Windows.Forms.Button()
        Me.btn_batal = New System.Windows.Forms.Button()
        Me.btn_simpan = New System.Windows.Forms.Button()
        Me.btn_tambah = New System.Windows.Forms.Button()
        Me.tbox4 = New System.Windows.Forms.TextBox()
        Me.date2 = New System.Windows.Forms.DateTimePicker()
        Me.com7 = New System.Windows.Forms.ComboBox()
        Me.com6 = New System.Windows.Forms.ComboBox()
        Me.com4 = New System.Windows.Forms.ComboBox()
        Me.com5 = New System.Windows.Forms.ComboBox()
        Me.com3 = New System.Windows.Forms.ComboBox()
        Me.rt = New System.Windows.Forms.RichTextBox()
        Me.com2 = New System.Windows.Forms.ComboBox()
        Me.com1 = New System.Windows.Forms.ComboBox()
        Me.lbl_judul = New System.Windows.Forms.Label()
        Me.DataGrid_Penduduk = New System.Windows.Forms.DataGridView()
        Me.date1 = New System.Windows.Forms.DateTimePicker()
        Me.tbox3 = New System.Windows.Forms.TextBox()
        Me.tbox2 = New System.Windows.Forms.TextBox()
        Me.tbox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.com8 = New System.Windows.Forms.ComboBox()
        Me.btn_hapus = New System.Windows.Forms.Button()
        Me.btn_edit = New System.Windows.Forms.Button()
        Me.btn_ref = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGrid_Penduduk, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_nik
        '
        Me.lbl_nik.AutoSize = True
        Me.lbl_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nik.Location = New System.Drawing.Point(65, 114)
        Me.lbl_nik.Name = "lbl_nik"
        Me.lbl_nik.Size = New System.Drawing.Size(25, 13)
        Me.lbl_nik.TabIndex = 0
        Me.lbl_nik.Text = "NIK"
        '
        'lbl_nama
        '
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(65, 164)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(35, 13)
        Me.lbl_nama.TabIndex = 1
        Me.lbl_nama.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lbl_tmptlahir
        '
        Me.lbl_tmptlahir.AutoSize = True
        Me.lbl_tmptlahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tmptlahir.Location = New System.Drawing.Point(65, 208)
        Me.lbl_tmptlahir.Name = "lbl_tmptlahir"
        Me.lbl_tmptlahir.Size = New System.Drawing.Size(69, 13)
        Me.lbl_tmptlahir.TabIndex = 2
        Me.lbl_tmptlahir.Text = "Tempat Lahir"
        '
        'lbl_tgllahir
        '
        Me.lbl_tgllahir.AutoSize = True
        Me.lbl_tgllahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tgllahir.Location = New System.Drawing.Point(65, 257)
        Me.lbl_tgllahir.Name = "lbl_tgllahir"
        Me.lbl_tgllahir.Size = New System.Drawing.Size(72, 13)
        Me.lbl_tgllahir.TabIndex = 3
        Me.lbl_tgllahir.Text = "Tanggal Lahir"
        '
        'lbl_jk
        '
        Me.lbl_jk.AutoSize = True
        Me.lbl_jk.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_jk.Location = New System.Drawing.Point(65, 300)
        Me.lbl_jk.Name = "lbl_jk"
        Me.lbl_jk.Size = New System.Drawing.Size(71, 13)
        Me.lbl_jk.TabIndex = 4
        Me.lbl_jk.Text = "Jenis Kelamin"
        '
        'lbl_goldar
        '
        Me.lbl_goldar.AutoSize = True
        Me.lbl_goldar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_goldar.Location = New System.Drawing.Point(65, 341)
        Me.lbl_goldar.Name = "lbl_goldar"
        Me.lbl_goldar.Size = New System.Drawing.Size(85, 13)
        Me.lbl_goldar.TabIndex = 5
        Me.lbl_goldar.Text = "Golongan Darah"
        '
        'lbl_alamat
        '
        Me.lbl_alamat.AutoSize = True
        Me.lbl_alamat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_alamat.Location = New System.Drawing.Point(65, 380)
        Me.lbl_alamat.Name = "lbl_alamat"
        Me.lbl_alamat.Size = New System.Drawing.Size(39, 13)
        Me.lbl_alamat.TabIndex = 6
        Me.lbl_alamat.Text = "Alamat"
        '
        'lbl_agama
        '
        Me.lbl_agama.AutoSize = True
        Me.lbl_agama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_agama.Location = New System.Drawing.Point(695, 109)
        Me.lbl_agama.Name = "lbl_agama"
        Me.lbl_agama.Size = New System.Drawing.Size(40, 13)
        Me.lbl_agama.TabIndex = 7
        Me.lbl_agama.Text = "Agama"
        '
        'lbl_pddknter
        '
        Me.lbl_pddknter.AutoSize = True
        Me.lbl_pddknter.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pddknter.Location = New System.Drawing.Point(695, 159)
        Me.lbl_pddknter.Name = "lbl_pddknter"
        Me.lbl_pddknter.Size = New System.Drawing.Size(102, 13)
        Me.lbl_pddknter.TabIndex = 8
        Me.lbl_pddknter.Text = "Pendidikan Terakhir"
        '
        'lbl_statuspddkn
        '
        Me.lbl_statuspddkn.AutoSize = True
        Me.lbl_statuspddkn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statuspddkn.Location = New System.Drawing.Point(697, 208)
        Me.lbl_statuspddkn.Name = "lbl_statuspddkn"
        Me.lbl_statuspddkn.Size = New System.Drawing.Size(93, 13)
        Me.lbl_statuspddkn.TabIndex = 9
        Me.lbl_statuspddkn.Text = "Status Pendidikan"
        '
        'lbl_pekerjaan
        '
        Me.lbl_pekerjaan.AutoSize = True
        Me.lbl_pekerjaan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pekerjaan.Location = New System.Drawing.Point(697, 251)
        Me.lbl_pekerjaan.Name = "lbl_pekerjaan"
        Me.lbl_pekerjaan.Size = New System.Drawing.Size(55, 13)
        Me.lbl_pekerjaan.TabIndex = 10
        Me.lbl_pekerjaan.Text = "Pekerjaan"
        '
        'lbl_notelp
        '
        Me.lbl_notelp.AutoSize = True
        Me.lbl_notelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_notelp.Location = New System.Drawing.Point(698, 337)
        Me.lbl_notelp.Name = "lbl_notelp"
        Me.lbl_notelp.Size = New System.Drawing.Size(54, 13)
        Me.lbl_notelp.TabIndex = 11
        Me.lbl_notelp.Text = "No Telfon"
        '
        'lbl_statuskwn
        '
        Me.lbl_statuskwn.AutoSize = True
        Me.lbl_statuskwn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statuskwn.Location = New System.Drawing.Point(695, 295)
        Me.lbl_statuskwn.Name = "lbl_statuskwn"
        Me.lbl_statuskwn.Size = New System.Drawing.Size(81, 13)
        Me.lbl_statuskwn.TabIndex = 12
        Me.lbl_statuskwn.Text = "Status Menikah"
        '
        'lbl_kwgnegara
        '
        Me.lbl_kwgnegara.AutoSize = True
        Me.lbl_kwgnegara.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_kwgnegara.Location = New System.Drawing.Point(698, 375)
        Me.lbl_kwgnegara.Name = "lbl_kwgnegara"
        Me.lbl_kwgnegara.Size = New System.Drawing.Size(94, 13)
        Me.lbl_kwgnegara.TabIndex = 13
        Me.lbl_kwgnegara.Text = "Kewarganegaraan"
        '
        'lbl_tglreg
        '
        Me.lbl_tglreg.AutoSize = True
        Me.lbl_tglreg.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tglreg.Location = New System.Drawing.Point(695, 413)
        Me.lbl_tglreg.Name = "lbl_tglreg"
        Me.lbl_tglreg.Size = New System.Drawing.Size(95, 13)
        Me.lbl_tglreg.TabIndex = 14
        Me.lbl_tglreg.Text = "Tanggal Registrasi"
        '
        'tbox_nik
        '
        Me.tbox_nik.Location = New System.Drawing.Point(182, 102)
        Me.tbox_nik.Name = "tbox_nik"
        Me.tbox_nik.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nik.TabIndex = 15
        '
        'tbox_nama
        '
        Me.tbox_nama.Location = New System.Drawing.Point(182, 152)
        Me.tbox_nama.Name = "tbox_nama"
        Me.tbox_nama.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nama.TabIndex = 16
        '
        'tbox_tmptlahir
        '
        Me.tbox_tmptlahir.Location = New System.Drawing.Point(182, 203)
        Me.tbox_tmptlahir.Name = "tbox_tmptlahir"
        Me.tbox_tmptlahir.Size = New System.Drawing.Size(448, 20)
        Me.tbox_tmptlahir.TabIndex = 17
        '
        'tgl_lahir
        '
        Me.tgl_lahir.Location = New System.Drawing.Point(182, 245)
        Me.tgl_lahir.Name = "tgl_lahir"
        Me.tgl_lahir.Size = New System.Drawing.Size(151, 20)
        Me.tgl_lahir.TabIndex = 18
        '
        'DataGridView1
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(12, 539)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1330, 182)
        Me.DataGridView1.TabIndex = 20
        '
        'judul
        '
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(546, 9)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(261, 29)
        Me.judul.TabIndex = 21
        Me.judul.Text = "Pendataan Penduduk"
        '
        'combo_jk
        '
        Me.combo_jk.FormattingEnabled = True
        Me.combo_jk.Location = New System.Drawing.Point(182, 290)
        Me.combo_jk.Name = "combo_jk"
        Me.combo_jk.Size = New System.Drawing.Size(151, 21)
        Me.combo_jk.TabIndex = 22
        '
        'combo_gd
        '
        Me.combo_gd.FormattingEnabled = True
        Me.combo_gd.Location = New System.Drawing.Point(182, 329)
        Me.combo_gd.Name = "combo_gd"
        Me.combo_gd.Size = New System.Drawing.Size(41, 21)
        Me.combo_gd.TabIndex = 23
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(182, 375)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(448, 51)
        Me.RichTextBox1.TabIndex = 24
        Me.RichTextBox1.Text = ""
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(841, 101)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(116, 21)
        Me.ComboBox1.TabIndex = 25
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(841, 200)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(116, 21)
        Me.ComboBox2.TabIndex = 26
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(841, 151)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox3.TabIndex = 27
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(841, 243)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox4.TabIndex = 28
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(841, 287)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox5.TabIndex = 29
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(841, 406)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(223, 20)
        Me.DateTimePicker1.TabIndex = 32
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(841, 330)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(223, 20)
        Me.TextBox2.TabIndex = 34
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(536, 471)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "Tambah"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(882, 472)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "Simpan"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1083, 472)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 37
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_keluar
        '
        Me.btn_keluar.Location = New System.Drawing.Point(1186, 472)
        Me.btn_keluar.Name = "btn_keluar"
        Me.btn_keluar.Size = New System.Drawing.Size(75, 23)
        Me.btn_keluar.TabIndex = 38
        Me.btn_keluar.Text = "keluar"
        Me.btn_keluar.UseVisualStyleBackColor = True
        '
        'btnkeluar
        '
        Me.btnkeluar.Location = New System.Drawing.Point(1186, 473)
        Me.btnkeluar.Name = "btnkeluar"
        Me.btnkeluar.Size = New System.Drawing.Size(75, 23)
        Me.btnkeluar.TabIndex = 110
        Me.btnkeluar.Text = "keluar"
        Me.btnkeluar.UseVisualStyleBackColor = True
        '
        'btn_batal
        '
        Me.btn_batal.Location = New System.Drawing.Point(1083, 473)
        Me.btn_batal.Name = "btn_batal"
        Me.btn_batal.Size = New System.Drawing.Size(75, 23)
        Me.btn_batal.TabIndex = 109
        Me.btn_batal.Text = "Batal"
        Me.btn_batal.UseVisualStyleBackColor = True
        '
        'btn_simpan
        '
        Me.btn_simpan.Location = New System.Drawing.Point(882, 473)
        Me.btn_simpan.Name = "btn_simpan"
        Me.btn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.btn_simpan.TabIndex = 108
        Me.btn_simpan.Text = "Simpan"
        Me.btn_simpan.UseVisualStyleBackColor = True
        '
        'btn_tambah
        '
        Me.btn_tambah.Location = New System.Drawing.Point(536, 472)
        Me.btn_tambah.Name = "btn_tambah"
        Me.btn_tambah.Size = New System.Drawing.Size(75, 23)
        Me.btn_tambah.TabIndex = 107
        Me.btn_tambah.Text = "Tambah"
        Me.btn_tambah.UseVisualStyleBackColor = True
        '
        'tbox4
        '
        Me.tbox4.Location = New System.Drawing.Point(841, 331)
        Me.tbox4.Name = "tbox4"
        Me.tbox4.Size = New System.Drawing.Size(223, 20)
        Me.tbox4.TabIndex = 106
        '
        'date2
        '
        Me.date2.Location = New System.Drawing.Point(841, 407)
        Me.date2.Name = "date2"
        Me.date2.Size = New System.Drawing.Size(223, 20)
        Me.date2.TabIndex = 104
        '
        'com7
        '
        Me.com7.FormattingEnabled = True
        Me.com7.Location = New System.Drawing.Point(841, 288)
        Me.com7.Name = "com7"
        Me.com7.Size = New System.Drawing.Size(163, 21)
        Me.com7.TabIndex = 103
        '
        'com6
        '
        Me.com6.FormattingEnabled = True
        Me.com6.Location = New System.Drawing.Point(841, 244)
        Me.com6.Name = "com6"
        Me.com6.Size = New System.Drawing.Size(163, 21)
        Me.com6.TabIndex = 102
        '
        'com4
        '
        Me.com4.FormattingEnabled = True
        Me.com4.Location = New System.Drawing.Point(841, 152)
        Me.com4.Name = "com4"
        Me.com4.Size = New System.Drawing.Size(163, 21)
        Me.com4.TabIndex = 101
        '
        'com5
        '
        Me.com5.FormattingEnabled = True
        Me.com5.Location = New System.Drawing.Point(841, 201)
        Me.com5.Name = "com5"
        Me.com5.Size = New System.Drawing.Size(116, 21)
        Me.com5.TabIndex = 100
        '
        'com3
        '
        Me.com3.FormattingEnabled = True
        Me.com3.Location = New System.Drawing.Point(841, 102)
        Me.com3.Name = "com3"
        Me.com3.Size = New System.Drawing.Size(116, 21)
        Me.com3.TabIndex = 99
        '
        'rt
        '
        Me.rt.Location = New System.Drawing.Point(182, 376)
        Me.rt.Name = "rt"
        Me.rt.Size = New System.Drawing.Size(448, 51)
        Me.rt.TabIndex = 98
        Me.rt.Text = ""
        '
        'com2
        '
        Me.com2.FormattingEnabled = True
        Me.com2.Location = New System.Drawing.Point(182, 330)
        Me.com2.Name = "com2"
        Me.com2.Size = New System.Drawing.Size(41, 21)
        Me.com2.TabIndex = 97
        '
        'com1
        '
        Me.com1.FormattingEnabled = True
        Me.com1.Location = New System.Drawing.Point(182, 291)
        Me.com1.Name = "com1"
        Me.com1.Size = New System.Drawing.Size(151, 21)
        Me.com1.TabIndex = 96
        '
        'lbl_judul
        '
        Me.lbl_judul.AutoSize = True
        Me.lbl_judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_judul.Location = New System.Drawing.Point(546, 10)
        Me.lbl_judul.Name = "lbl_judul"
        Me.lbl_judul.Size = New System.Drawing.Size(261, 29)
        Me.lbl_judul.TabIndex = 95
        Me.lbl_judul.Text = "Pendataan Penduduk"
        '
        'DataGrid_Penduduk
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid_Penduduk.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGrid_Penduduk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGrid_Penduduk.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGrid_Penduduk.Location = New System.Drawing.Point(12, 540)
        Me.DataGrid_Penduduk.Name = "DataGrid_Penduduk"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid_Penduduk.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGrid_Penduduk.Size = New System.Drawing.Size(1330, 182)
        Me.DataGrid_Penduduk.TabIndex = 94
        '
        'date1
        '
        Me.date1.Location = New System.Drawing.Point(182, 246)
        Me.date1.Name = "date1"
        Me.date1.Size = New System.Drawing.Size(151, 20)
        Me.date1.TabIndex = 93
        '
        'tbox3
        '
        Me.tbox3.Location = New System.Drawing.Point(182, 204)
        Me.tbox3.Name = "tbox3"
        Me.tbox3.Size = New System.Drawing.Size(448, 20)
        Me.tbox3.TabIndex = 92
        '
        'tbox2
        '
        Me.tbox2.Location = New System.Drawing.Point(182, 153)
        Me.tbox2.Name = "tbox2"
        Me.tbox2.Size = New System.Drawing.Size(448, 20)
        Me.tbox2.TabIndex = 91
        '
        'tbox1
        '
        Me.tbox1.Location = New System.Drawing.Point(182, 103)
        Me.tbox1.Name = "tbox1"
        Me.tbox1.Size = New System.Drawing.Size(448, 20)
        Me.tbox1.TabIndex = 90
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(695, 414)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 13)
        Me.Label2.TabIndex = 89
        Me.Label2.Text = "Tanggal Registrasi"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(698, 376)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 13)
        Me.Label3.TabIndex = 88
        Me.Label3.Text = "Kewarganegaraan"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(695, 296)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 13)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "Status Menikah"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(698, 338)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 13)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "No Telfon"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(697, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Pekerjaan"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(697, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 84
        Me.Label7.Text = "Status Pendidikan"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(695, 160)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(102, 13)
        Me.Label8.TabIndex = 83
        Me.Label8.Text = "Pendidikan Terakhir"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(695, 109)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 13)
        Me.Label9.TabIndex = 82
        Me.Label9.Text = "Agama"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(65, 381)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 13)
        Me.Label10.TabIndex = 81
        Me.Label10.Text = "Alamat"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(65, 342)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 13)
        Me.Label11.TabIndex = 80
        Me.Label11.Text = "Golongan Darah"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(65, 301)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(71, 13)
        Me.Label12.TabIndex = 79
        Me.Label12.Text = "Jenis Kelamin"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(65, 258)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(72, 13)
        Me.Label13.TabIndex = 78
        Me.Label13.Text = "Tanggal Lahir"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(65, 209)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(69, 13)
        Me.Label14.TabIndex = 77
        Me.Label14.Text = "Tempat Lahir"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(65, 165)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 76
        Me.Label15.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(65, 110)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(25, 13)
        Me.Label16.TabIndex = 75
        Me.Label16.Text = "NIK"
        '
        'com8
        '
        Me.com8.FormattingEnabled = True
        Me.com8.Location = New System.Drawing.Point(841, 367)
        Me.com8.Name = "com8"
        Me.com8.Size = New System.Drawing.Size(163, 21)
        Me.com8.TabIndex = 111
        '
        'btn_hapus
        '
        Me.btn_hapus.Location = New System.Drawing.Point(772, 472)
        Me.btn_hapus.Name = "btn_hapus"
        Me.btn_hapus.Size = New System.Drawing.Size(75, 23)
        Me.btn_hapus.TabIndex = 112
        Me.btn_hapus.Text = "Hapus"
        Me.btn_hapus.UseVisualStyleBackColor = True
        '
        'btn_edit
        '
        Me.btn_edit.Location = New System.Drawing.Point(657, 472)
        Me.btn_edit.Name = "btn_edit"
        Me.btn_edit.Size = New System.Drawing.Size(75, 23)
        Me.btn_edit.TabIndex = 113
        Me.btn_edit.Text = "Edit"
        Me.btn_edit.UseVisualStyleBackColor = True
        '
        'btn_ref
        '
        Me.btn_ref.Location = New System.Drawing.Point(989, 473)
        Me.btn_ref.Name = "btn_ref"
        Me.btn_ref.Size = New System.Drawing.Size(75, 23)
        Me.btn_ref.TabIndex = 114
        Me.btn_ref.Text = "Refresh"
        Me.btn_ref.UseVisualStyleBackColor = True
        '
        'form_penduduk
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1354, 733)
        Me.Controls.Add(Me.btn_ref)
        Me.Controls.Add(Me.btn_edit)
        Me.Controls.Add(Me.btn_hapus)
        Me.Controls.Add(Me.com8)
        Me.Controls.Add(Me.btnkeluar)
        Me.Controls.Add(Me.btn_batal)
        Me.Controls.Add(Me.btn_simpan)
        Me.Controls.Add(Me.btn_tambah)
        Me.Controls.Add(Me.tbox4)
        Me.Controls.Add(Me.date2)
        Me.Controls.Add(Me.com7)
        Me.Controls.Add(Me.com6)
        Me.Controls.Add(Me.com4)
        Me.Controls.Add(Me.com5)
        Me.Controls.Add(Me.com3)
        Me.Controls.Add(Me.rt)
        Me.Controls.Add(Me.com2)
        Me.Controls.Add(Me.com1)
        Me.Controls.Add(Me.lbl_judul)
        Me.Controls.Add(Me.DataGrid_Penduduk)
        Me.Controls.Add(Me.date1)
        Me.Controls.Add(Me.tbox3)
        Me.Controls.Add(Me.tbox2)
        Me.Controls.Add(Me.tbox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.btn_keluar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.combo_gd)
        Me.Controls.Add(Me.combo_jk)
        Me.Controls.Add(Me.judul)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.tgl_lahir)
        Me.Controls.Add(Me.tbox_tmptlahir)
        Me.Controls.Add(Me.tbox_nama)
        Me.Controls.Add(Me.tbox_nik)
        Me.Controls.Add(Me.lbl_tglreg)
        Me.Controls.Add(Me.lbl_kwgnegara)
        Me.Controls.Add(Me.lbl_statuskwn)
        Me.Controls.Add(Me.lbl_notelp)
        Me.Controls.Add(Me.lbl_pekerjaan)
        Me.Controls.Add(Me.lbl_statuspddkn)
        Me.Controls.Add(Me.lbl_pddknter)
        Me.Controls.Add(Me.lbl_agama)
        Me.Controls.Add(Me.lbl_alamat)
        Me.Controls.Add(Me.lbl_goldar)
        Me.Controls.Add(Me.lbl_jk)
        Me.Controls.Add(Me.lbl_tgllahir)
        Me.Controls.Add(Me.lbl_tmptlahir)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.lbl_nik)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "form_penduduk"
        Me.Text = "form_penduduk"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGrid_Penduduk, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_nik As System.Windows.Forms.Label
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
    Friend WithEvents lbl_tmptlahir As System.Windows.Forms.Label
    Friend WithEvents lbl_tgllahir As System.Windows.Forms.Label
    Friend WithEvents lbl_jk As System.Windows.Forms.Label
    Friend WithEvents lbl_goldar As System.Windows.Forms.Label
    Friend WithEvents lbl_alamat As System.Windows.Forms.Label
    Friend WithEvents lbl_agama As System.Windows.Forms.Label
    Friend WithEvents lbl_pddknter As System.Windows.Forms.Label
    Friend WithEvents lbl_statuspddkn As System.Windows.Forms.Label
    Friend WithEvents lbl_pekerjaan As System.Windows.Forms.Label
    Friend WithEvents lbl_notelp As System.Windows.Forms.Label
    Friend WithEvents lbl_statuskwn As System.Windows.Forms.Label
    Friend WithEvents lbl_kwgnegara As System.Windows.Forms.Label
    Friend WithEvents lbl_tglreg As System.Windows.Forms.Label
    Friend WithEvents tbox_nik As System.Windows.Forms.TextBox
    Friend WithEvents tbox_nama As System.Windows.Forms.TextBox
    Friend WithEvents tbox_tmptlahir As System.Windows.Forms.TextBox
    Friend WithEvents tgl_lahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents combo_jk As System.Windows.Forms.ComboBox
    Friend WithEvents combo_gd As System.Windows.Forms.ComboBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btn_keluar As System.Windows.Forms.Button
    Friend WithEvents btnkeluar As System.Windows.Forms.Button
    Friend WithEvents btn_batal As System.Windows.Forms.Button
    Friend WithEvents btn_simpan As System.Windows.Forms.Button
    Friend WithEvents btn_tambah As System.Windows.Forms.Button
    Friend WithEvents tbox4 As System.Windows.Forms.TextBox
    Friend WithEvents date2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents com7 As System.Windows.Forms.ComboBox
    Friend WithEvents com6 As System.Windows.Forms.ComboBox
    Friend WithEvents com4 As System.Windows.Forms.ComboBox
    Friend WithEvents com5 As System.Windows.Forms.ComboBox
    Friend WithEvents com3 As System.Windows.Forms.ComboBox
    Friend WithEvents rt As System.Windows.Forms.RichTextBox
    Friend WithEvents com2 As System.Windows.Forms.ComboBox
    Friend WithEvents com1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_judul As System.Windows.Forms.Label
    Friend WithEvents DataGrid_Penduduk As System.Windows.Forms.DataGridView
    Friend WithEvents date1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbox3 As System.Windows.Forms.TextBox
    Friend WithEvents tbox2 As System.Windows.Forms.TextBox
    Friend WithEvents tbox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents com8 As System.Windows.Forms.ComboBox
    Friend WithEvents btn_hapus As System.Windows.Forms.Button
    Friend WithEvents btn_edit As System.Windows.Forms.Button
    Friend WithEvents btn_ref As System.Windows.Forms.Button

End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_kelahiran
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btn_keluar = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_simpan = New System.Windows.Forms.Button()
        Me.btn_tambah = New System.Windows.Forms.Button()
        Me.rtbox_alamat = New System.Windows.Forms.RichTextBox()
        Me.combo_jk = New System.Windows.Forms.ComboBox()
        Me.judul = New System.Windows.Forms.Label()
        Me.DataGrid_Penduduk = New System.Windows.Forms.DataGridView()
        Me.tgl_lahir = New System.Windows.Forms.DateTimePicker()
        Me.tbox_tmptlahir = New System.Windows.Forms.TextBox()
        Me.tbox_nama = New System.Windows.Forms.TextBox()
        Me.tbox_noakta = New System.Windows.Forms.TextBox()
        Me.lbl_alamat = New System.Windows.Forms.Label()
        Me.lbl_jk = New System.Windows.Forms.Label()
        Me.lbl_tgllahir = New System.Windows.Forms.Label()
        Me.lbl_tmptlahir = New System.Windows.Forms.Label()
        Me.lbl_nama = New System.Windows.Forms.Label()
        Me.lbl_noakta = New System.Windows.Forms.Label()
        Me.tbox_hrlahir = New System.Windows.Forms.TextBox()
        Me.lbl_hrlahir = New System.Windows.Forms.Label()
        Me.lbl_pukul = New System.Windows.Forms.Label()
        Me.tbox_pukul = New System.Windows.Forms.TextBox()
        Me.tbox_jenkel = New System.Windows.Forms.TextBox()
        Me.lbl_jenkel = New System.Windows.Forms.Label()
        Me.tbox_kelke = New System.Windows.Forms.TextBox()
        Me.lbl_kelke = New System.Windows.Forms.Label()
        Me.tbox_penolongkel = New System.Windows.Forms.TextBox()
        Me.lbl_penonolongkel = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.lbl_berbayi = New System.Windows.Forms.Label()
        Me.tbox_pnjngbayi = New System.Windows.Forms.TextBox()
        Me.lbl_pnjgbayi = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.lbl_namaayh = New System.Windows.Forms.Label()
        Me.tbox_namaibu = New System.Windows.Forms.TextBox()
        Me.lbl_namaibu = New System.Windows.Forms.Label()
        CType(Me.DataGrid_Penduduk, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_keluar
        '
        Me.btn_keluar.Location = New System.Drawing.Point(1190, 477)
        Me.btn_keluar.Name = "btn_keluar"
        Me.btn_keluar.Size = New System.Drawing.Size(75, 23)
        Me.btn_keluar.TabIndex = 74
        Me.btn_keluar.Text = "keluar"
        Me.btn_keluar.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1087, 477)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 73
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_simpan
        '
        Me.btn_simpan.Location = New System.Drawing.Point(973, 477)
        Me.btn_simpan.Name = "btn_simpan"
        Me.btn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.btn_simpan.TabIndex = 72
        Me.btn_simpan.Text = "Simpan"
        Me.btn_simpan.UseVisualStyleBackColor = True
        '
        'btn_tambah
        '
        Me.btn_tambah.Location = New System.Drawing.Point(863, 477)
        Me.btn_tambah.Name = "btn_tambah"
        Me.btn_tambah.Size = New System.Drawing.Size(75, 23)
        Me.btn_tambah.TabIndex = 71
        Me.btn_tambah.Text = "Tambah"
        Me.btn_tambah.UseVisualStyleBackColor = True
        '
        'rtbox_alamat
        '
        Me.rtbox_alamat.Location = New System.Drawing.Point(875, 365)
        Me.rtbox_alamat.Name = "rtbox_alamat"
        Me.rtbox_alamat.Size = New System.Drawing.Size(448, 51)
        Me.rtbox_alamat.TabIndex = 62
        Me.rtbox_alamat.Text = ""
        '
        'combo_jk
        '
        Me.combo_jk.FormattingEnabled = True
        Me.combo_jk.Location = New System.Drawing.Point(186, 205)
        Me.combo_jk.Name = "combo_jk"
        Me.combo_jk.Size = New System.Drawing.Size(448, 21)
        Me.combo_jk.TabIndex = 60
        '
        'judul
        '
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(550, 14)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(255, 29)
        Me.judul.TabIndex = 59
        Me.judul.Text = "Pendataan Kelahiran"
        '
        'DataGrid_Penduduk
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid_Penduduk.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGrid_Penduduk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGrid_Penduduk.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGrid_Penduduk.Location = New System.Drawing.Point(16, 544)
        Me.DataGrid_Penduduk.Name = "DataGrid_Penduduk"
        Me.DataGrid_Penduduk.Size = New System.Drawing.Size(1330, 182)
        Me.DataGrid_Penduduk.TabIndex = 58
        '
        'tgl_lahir
        '
        Me.tgl_lahir.Location = New System.Drawing.Point(186, 337)
        Me.tgl_lahir.Name = "tgl_lahir"
        Me.tgl_lahir.Size = New System.Drawing.Size(448, 20)
        Me.tgl_lahir.TabIndex = 57
        '
        'tbox_tmptlahir
        '
        Me.tbox_tmptlahir.Location = New System.Drawing.Point(186, 248)
        Me.tbox_tmptlahir.Name = "tbox_tmptlahir"
        Me.tbox_tmptlahir.Size = New System.Drawing.Size(448, 20)
        Me.tbox_tmptlahir.TabIndex = 56
        '
        'tbox_nama
        '
        Me.tbox_nama.Location = New System.Drawing.Point(186, 157)
        Me.tbox_nama.Name = "tbox_nama"
        Me.tbox_nama.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nama.TabIndex = 55
        '
        'tbox_noakta
        '
        Me.tbox_noakta.Location = New System.Drawing.Point(186, 107)
        Me.tbox_noakta.Name = "tbox_noakta"
        Me.tbox_noakta.Size = New System.Drawing.Size(448, 20)
        Me.tbox_noakta.TabIndex = 54
        '
        'lbl_alamat
        '
        Me.lbl_alamat.AutoSize = True
        Me.lbl_alamat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_alamat.Location = New System.Drawing.Point(730, 368)
        Me.lbl_alamat.Name = "lbl_alamat"
        Me.lbl_alamat.Size = New System.Drawing.Size(39, 13)
        Me.lbl_alamat.TabIndex = 45
        Me.lbl_alamat.Text = "Alamat"
        '
        'lbl_jk
        '
        Me.lbl_jk.AutoSize = True
        Me.lbl_jk.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_jk.Location = New System.Drawing.Point(70, 213)
        Me.lbl_jk.Name = "lbl_jk"
        Me.lbl_jk.Size = New System.Drawing.Size(71, 13)
        Me.lbl_jk.TabIndex = 43
        Me.lbl_jk.Text = "Jenis Kelamin"
        '
        'lbl_tgllahir
        '
        Me.lbl_tgllahir.AutoSize = True
        Me.lbl_tgllahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tgllahir.Location = New System.Drawing.Point(70, 343)
        Me.lbl_tgllahir.Name = "lbl_tgllahir"
        Me.lbl_tgllahir.Size = New System.Drawing.Size(72, 13)
        Me.lbl_tgllahir.TabIndex = 42
        Me.lbl_tgllahir.Text = "Tanggal Lahir"
        '
        'lbl_tmptlahir
        '
        Me.lbl_tmptlahir.AutoSize = True
        Me.lbl_tmptlahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tmptlahir.Location = New System.Drawing.Point(69, 256)
        Me.lbl_tmptlahir.Name = "lbl_tmptlahir"
        Me.lbl_tmptlahir.Size = New System.Drawing.Size(69, 13)
        Me.lbl_tmptlahir.TabIndex = 41
        Me.lbl_tmptlahir.Text = "Tempat Lahir"
        '
        'lbl_nama
        '
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(69, 164)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(35, 13)
        Me.lbl_nama.TabIndex = 40
        Me.lbl_nama.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lbl_noakta
        '
        Me.lbl_noakta.AutoSize = True
        Me.lbl_noakta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_noakta.Location = New System.Drawing.Point(69, 114)
        Me.lbl_noakta.Name = "lbl_noakta"
        Me.lbl_noakta.Size = New System.Drawing.Size(46, 13)
        Me.lbl_noakta.TabIndex = 39
        Me.lbl_noakta.Text = "No Akta"
        '
        'tbox_hrlahir
        '
        Me.tbox_hrlahir.Location = New System.Drawing.Point(186, 292)
        Me.tbox_hrlahir.Name = "tbox_hrlahir"
        Me.tbox_hrlahir.Size = New System.Drawing.Size(448, 20)
        Me.tbox_hrlahir.TabIndex = 76
        '
        'lbl_hrlahir
        '
        Me.lbl_hrlahir.AutoSize = True
        Me.lbl_hrlahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hrlahir.Location = New System.Drawing.Point(70, 300)
        Me.lbl_hrlahir.Name = "lbl_hrlahir"
        Me.lbl_hrlahir.Size = New System.Drawing.Size(69, 13)
        Me.lbl_hrlahir.TabIndex = 75
        Me.lbl_hrlahir.Text = "Tempat Lahir"
        '
        'lbl_pukul
        '
        Me.lbl_pukul.AutoSize = True
        Me.lbl_pukul.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pukul.Location = New System.Drawing.Point(70, 387)
        Me.lbl_pukul.Name = "lbl_pukul"
        Me.lbl_pukul.Size = New System.Drawing.Size(34, 13)
        Me.lbl_pukul.TabIndex = 77
        Me.lbl_pukul.Text = "Pukul"
        '
        'tbox_pukul
        '
        Me.tbox_pukul.Location = New System.Drawing.Point(186, 380)
        Me.tbox_pukul.Name = "tbox_pukul"
        Me.tbox_pukul.Size = New System.Drawing.Size(57, 20)
        Me.tbox_pukul.TabIndex = 78
        '
        'tbox_jenkel
        '
        Me.tbox_jenkel.Location = New System.Drawing.Point(186, 418)
        Me.tbox_jenkel.Name = "tbox_jenkel"
        Me.tbox_jenkel.Size = New System.Drawing.Size(448, 20)
        Me.tbox_jenkel.TabIndex = 80
        '
        'lbl_jenkel
        '
        Me.lbl_jenkel.AutoSize = True
        Me.lbl_jenkel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_jenkel.Location = New System.Drawing.Point(70, 425)
        Me.lbl_jenkel.Name = "lbl_jenkel"
        Me.lbl_jenkel.Size = New System.Drawing.Size(78, 13)
        Me.lbl_jenkel.TabIndex = 79
        Me.lbl_jenkel.Text = "Jenis Kelahiran"
        '
        'tbox_kelke
        '
        Me.tbox_kelke.Location = New System.Drawing.Point(186, 458)
        Me.tbox_kelke.Name = "tbox_kelke"
        Me.tbox_kelke.Size = New System.Drawing.Size(31, 20)
        Me.tbox_kelke.TabIndex = 82
        '
        'lbl_kelke
        '
        Me.lbl_kelke.AutoSize = True
        Me.lbl_kelke.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_kelke.Location = New System.Drawing.Point(70, 465)
        Me.lbl_kelke.Name = "lbl_kelke"
        Me.lbl_kelke.Size = New System.Drawing.Size(70, 13)
        Me.lbl_kelke.TabIndex = 81
        Me.lbl_kelke.Text = "Kelahiran Ke-"
        '
        'tbox_penolongkel
        '
        Me.tbox_penolongkel.Location = New System.Drawing.Point(875, 107)
        Me.tbox_penolongkel.Name = "tbox_penolongkel"
        Me.tbox_penolongkel.Size = New System.Drawing.Size(448, 20)
        Me.tbox_penolongkel.TabIndex = 84
        '
        'lbl_penonolongkel
        '
        Me.lbl_penonolongkel.AutoSize = True
        Me.lbl_penonolongkel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_penonolongkel.Location = New System.Drawing.Point(730, 114)
        Me.lbl_penonolongkel.Name = "lbl_penonolongkel"
        Me.lbl_penonolongkel.Size = New System.Drawing.Size(99, 13)
        Me.lbl_penonolongkel.TabIndex = 83
        Me.lbl_penonolongkel.Text = "Penolong Kelahiran"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(875, 164)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(448, 20)
        Me.TextBox1.TabIndex = 86
        '
        'lbl_berbayi
        '
        Me.lbl_berbayi.AutoSize = True
        Me.lbl_berbayi.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_berbayi.Location = New System.Drawing.Point(730, 171)
        Me.lbl_berbayi.Name = "lbl_berbayi"
        Me.lbl_berbayi.Size = New System.Drawing.Size(55, 13)
        Me.lbl_berbayi.TabIndex = 85
        Me.lbl_berbayi.Text = "Berat Bayi"
        '
        'tbox_pnjngbayi
        '
        Me.tbox_pnjngbayi.Location = New System.Drawing.Point(875, 213)
        Me.tbox_pnjngbayi.Name = "tbox_pnjngbayi"
        Me.tbox_pnjngbayi.Size = New System.Drawing.Size(448, 20)
        Me.tbox_pnjngbayi.TabIndex = 88
        '
        'lbl_pnjgbayi
        '
        Me.lbl_pnjgbayi.AutoSize = True
        Me.lbl_pnjgbayi.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pnjgbayi.Location = New System.Drawing.Point(730, 220)
        Me.lbl_pnjgbayi.Name = "lbl_pnjgbayi"
        Me.lbl_pnjgbayi.Size = New System.Drawing.Size(55, 13)
        Me.lbl_pnjgbayi.TabIndex = 87
        Me.lbl_pnjgbayi.Text = "Berat Bayi"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(875, 263)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(448, 20)
        Me.TextBox2.TabIndex = 90
        '
        'lbl_namaayh
        '
        Me.lbl_namaayh.AutoSize = True
        Me.lbl_namaayh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_namaayh.Location = New System.Drawing.Point(730, 270)
        Me.lbl_namaayh.Name = "lbl_namaayh"
        Me.lbl_namaayh.Size = New System.Drawing.Size(62, 13)
        Me.lbl_namaayh.TabIndex = 89
        Me.lbl_namaayh.Text = "Nama Ayah"
        '
        'tbox_namaibu
        '
        Me.tbox_namaibu.Location = New System.Drawing.Point(875, 316)
        Me.tbox_namaibu.Name = "tbox_namaibu"
        Me.tbox_namaibu.Size = New System.Drawing.Size(448, 20)
        Me.tbox_namaibu.TabIndex = 92
        '
        'lbl_namaibu
        '
        Me.lbl_namaibu.AutoSize = True
        Me.lbl_namaibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_namaibu.Location = New System.Drawing.Point(730, 319)
        Me.lbl_namaibu.Name = "lbl_namaibu"
        Me.lbl_namaibu.Size = New System.Drawing.Size(53, 13)
        Me.lbl_namaibu.TabIndex = 91
        Me.lbl_namaibu.Text = "Nama Ibu"
        '
        'form_kelahiran
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.tbox_namaibu)
        Me.Controls.Add(Me.lbl_namaibu)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.lbl_namaayh)
        Me.Controls.Add(Me.tbox_pnjngbayi)
        Me.Controls.Add(Me.lbl_pnjgbayi)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lbl_berbayi)
        Me.Controls.Add(Me.tbox_penolongkel)
        Me.Controls.Add(Me.lbl_penonolongkel)
        Me.Controls.Add(Me.tbox_kelke)
        Me.Controls.Add(Me.lbl_kelke)
        Me.Controls.Add(Me.tbox_jenkel)
        Me.Controls.Add(Me.lbl_jenkel)
        Me.Controls.Add(Me.tbox_pukul)
        Me.Controls.Add(Me.lbl_pukul)
        Me.Controls.Add(Me.tbox_hrlahir)
        Me.Controls.Add(Me.lbl_hrlahir)
        Me.Controls.Add(Me.btn_keluar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btn_simpan)
        Me.Controls.Add(Me.btn_tambah)
        Me.Controls.Add(Me.rtbox_alamat)
        Me.Controls.Add(Me.combo_jk)
        Me.Controls.Add(Me.judul)
        Me.Controls.Add(Me.DataGrid_Penduduk)
        Me.Controls.Add(Me.tgl_lahir)
        Me.Controls.Add(Me.tbox_tmptlahir)
        Me.Controls.Add(Me.tbox_nama)
        Me.Controls.Add(Me.tbox_noakta)
        Me.Controls.Add(Me.lbl_alamat)
        Me.Controls.Add(Me.lbl_jk)
        Me.Controls.Add(Me.lbl_tgllahir)
        Me.Controls.Add(Me.lbl_tmptlahir)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.lbl_noakta)
        Me.Name = "form_kelahiran"
        Me.Text = "form_kelahiran"
        CType(Me.DataGrid_Penduduk, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_keluar As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btn_simpan As System.Windows.Forms.Button
    Friend WithEvents btn_tambah As System.Windows.Forms.Button
    Friend WithEvents rtbox_alamat As System.Windows.Forms.RichTextBox
    Friend WithEvents combo_jk As System.Windows.Forms.ComboBox
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents DataGrid_Penduduk As System.Windows.Forms.DataGridView
    Friend WithEvents tgl_lahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbox_tmptlahir As System.Windows.Forms.TextBox
    Friend WithEvents tbox_nama As System.Windows.Forms.TextBox
    Friend WithEvents tbox_noakta As System.Windows.Forms.TextBox
    Friend WithEvents lbl_alamat As System.Windows.Forms.Label
    Friend WithEvents lbl_jk As System.Windows.Forms.Label
    Friend WithEvents lbl_tgllahir As System.Windows.Forms.Label
    Friend WithEvents lbl_tmptlahir As System.Windows.Forms.Label
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
    Friend WithEvents lbl_noakta As System.Windows.Forms.Label
    Friend WithEvents tbox_hrlahir As System.Windows.Forms.TextBox
    Friend WithEvents lbl_hrlahir As System.Windows.Forms.Label
    Friend WithEvents lbl_pukul As System.Windows.Forms.Label
    Friend WithEvents tbox_pukul As System.Windows.Forms.TextBox
    Friend WithEvents tbox_jenkel As System.Windows.Forms.TextBox
    Friend WithEvents lbl_jenkel As System.Windows.Forms.Label
    Friend WithEvents tbox_kelke As System.Windows.Forms.TextBox
    Friend WithEvents lbl_kelke As System.Windows.Forms.Label
    Friend WithEvents tbox_penolongkel As System.Windows.Forms.TextBox
    Friend WithEvents lbl_penonolongkel As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_berbayi As System.Windows.Forms.Label
    Friend WithEvents tbox_pnjngbayi As System.Windows.Forms.TextBox
    Friend WithEvents lbl_pnjgbayi As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_namaayh As System.Windows.Forms.Label
    Friend WithEvents tbox_namaibu As System.Windows.Forms.TextBox
    Friend WithEvents lbl_namaibu As System.Windows.Forms.Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_pendatang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.judul = New System.Windows.Forms.Label()
        Me.tgl_datang = New System.Windows.Forms.DateTimePicker()
        Me.lbl_tgldatang = New System.Windows.Forms.Label()
        Me.rtbox_alamatasal = New System.Windows.Forms.RichTextBox()
        Me.lbl_alamatasal = New System.Windows.Forms.Label()
        Me.rtbox_almttujuan = New System.Windows.Forms.RichTextBox()
        Me.lbl_almttujuan = New System.Windows.Forms.Label()
        Me.rtbox_ket = New System.Windows.Forms.RichTextBox()
        Me.lbl_ket = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btn_keluar = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_simpan = New System.Windows.Forms.Button()
        Me.btn_tambah = New System.Windows.Forms.Button()
        Me.tbox_nama = New System.Windows.Forms.TextBox()
        Me.lbl_nama = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'judul
        '
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(620, 25)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(269, 29)
        Me.judul.TabIndex = 60
        Me.judul.Text = "Pendataan Pendatang"
        '
        'tgl_datang
        '
        Me.tgl_datang.Location = New System.Drawing.Point(199, 190)
        Me.tgl_datang.Name = "tgl_datang"
        Me.tgl_datang.Size = New System.Drawing.Size(448, 20)
        Me.tgl_datang.TabIndex = 62
        '
        'lbl_tgldatang
        '
        Me.lbl_tgldatang.AutoSize = True
        Me.lbl_tgldatang.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tgldatang.Location = New System.Drawing.Point(83, 196)
        Me.lbl_tgldatang.Name = "lbl_tgldatang"
        Me.lbl_tgldatang.Size = New System.Drawing.Size(84, 13)
        Me.lbl_tgldatang.TabIndex = 61
        Me.lbl_tgldatang.Text = "Tanggal Datang"
        '
        'rtbox_alamatasal
        '
        Me.rtbox_alamatasal.Location = New System.Drawing.Point(199, 241)
        Me.rtbox_alamatasal.Name = "rtbox_alamatasal"
        Me.rtbox_alamatasal.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_alamatasal.TabIndex = 64
        Me.rtbox_alamatasal.Text = ""
        '
        'lbl_alamatasal
        '
        Me.lbl_alamatasal.AutoSize = True
        Me.lbl_alamatasal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_alamatasal.Location = New System.Drawing.Point(83, 244)
        Me.lbl_alamatasal.Name = "lbl_alamatasal"
        Me.lbl_alamatasal.Size = New System.Drawing.Size(62, 13)
        Me.lbl_alamatasal.TabIndex = 63
        Me.lbl_alamatasal.Text = "Alamat Asal"
        '
        'rtbox_almttujuan
        '
        Me.rtbox_almttujuan.Location = New System.Drawing.Point(199, 309)
        Me.rtbox_almttujuan.Name = "rtbox_almttujuan"
        Me.rtbox_almttujuan.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_almttujuan.TabIndex = 66
        Me.rtbox_almttujuan.Text = ""
        '
        'lbl_almttujuan
        '
        Me.lbl_almttujuan.AutoSize = True
        Me.lbl_almttujuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_almttujuan.Location = New System.Drawing.Point(83, 312)
        Me.lbl_almttujuan.Name = "lbl_almttujuan"
        Me.lbl_almttujuan.Size = New System.Drawing.Size(75, 13)
        Me.lbl_almttujuan.TabIndex = 65
        Me.lbl_almttujuan.Text = "Alamat Tujuan"
        '
        'rtbox_ket
        '
        Me.rtbox_ket.Location = New System.Drawing.Point(199, 374)
        Me.rtbox_ket.Name = "rtbox_ket"
        Me.rtbox_ket.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_ket.TabIndex = 68
        Me.rtbox_ket.Text = ""
        '
        'lbl_ket
        '
        Me.lbl_ket.AutoSize = True
        Me.lbl_ket.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ket.Location = New System.Drawing.Point(83, 377)
        Me.lbl_ket.Name = "lbl_ket"
        Me.lbl_ket.Size = New System.Drawing.Size(62, 13)
        Me.lbl_ket.TabIndex = 67
        Me.lbl_ket.Text = "Keterangan"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(804, 139)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(510, 569)
        Me.DataGridView1.TabIndex = 69
        '
        'btn_keluar
        '
        Me.btn_keluar.Location = New System.Drawing.Point(514, 494)
        Me.btn_keluar.Name = "btn_keluar"
        Me.btn_keluar.Size = New System.Drawing.Size(75, 23)
        Me.btn_keluar.TabIndex = 78
        Me.btn_keluar.Text = "keluar"
        Me.btn_keluar.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(411, 494)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 77
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_simpan
        '
        Me.btn_simpan.Location = New System.Drawing.Point(297, 494)
        Me.btn_simpan.Name = "btn_simpan"
        Me.btn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.btn_simpan.TabIndex = 76
        Me.btn_simpan.Text = "Simpan"
        Me.btn_simpan.UseVisualStyleBackColor = True
        '
        'btn_tambah
        '
        Me.btn_tambah.Location = New System.Drawing.Point(187, 494)
        Me.btn_tambah.Name = "btn_tambah"
        Me.btn_tambah.Size = New System.Drawing.Size(75, 23)
        Me.btn_tambah.TabIndex = 75
        Me.btn_tambah.Text = "Tambah"
        Me.btn_tambah.UseVisualStyleBackColor = True
        '
        'tbox_nama
        '
        Me.tbox_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbox_nama.Location = New System.Drawing.Point(199, 139)
        Me.tbox_nama.Name = "tbox_nama"
        Me.tbox_nama.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nama.TabIndex = 96
        '
        'lbl_nama
        '
        Me.lbl_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(83, 146)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(35, 13)
        Me.lbl_nama.TabIndex = 95
        Me.lbl_nama.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'form_pendatang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.tbox_nama)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.btn_keluar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btn_simpan)
        Me.Controls.Add(Me.btn_tambah)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.rtbox_ket)
        Me.Controls.Add(Me.lbl_ket)
        Me.Controls.Add(Me.rtbox_almttujuan)
        Me.Controls.Add(Me.lbl_almttujuan)
        Me.Controls.Add(Me.rtbox_alamatasal)
        Me.Controls.Add(Me.lbl_alamatasal)
        Me.Controls.Add(Me.tgl_datang)
        Me.Controls.Add(Me.lbl_tgldatang)
        Me.Controls.Add(Me.judul)
        Me.Name = "form_pendatang"
        Me.Text = "form_pendatang"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents tgl_datang As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_tgldatang As System.Windows.Forms.Label
    Friend WithEvents rtbox_alamatasal As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_alamatasal As System.Windows.Forms.Label
    Friend WithEvents rtbox_almttujuan As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_almttujuan As System.Windows.Forms.Label
    Friend WithEvents rtbox_ket As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_ket As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btn_keluar As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btn_simpan As System.Windows.Forms.Button
    Friend WithEvents btn_tambah As System.Windows.Forms.Button
    Friend WithEvents tbox_nama As System.Windows.Forms.TextBox
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
End Class

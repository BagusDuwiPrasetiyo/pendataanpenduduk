﻿Imports MySql.Data.MySqlClient

Public Class form_penduduk
    Private Sub form_penduduk_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call CenterToScreen()
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        tutup()
        tampilGrid()
        aturDGV()
    End Sub
    Sub tutup()
        tbox1.Enabled = False
        tbox2.Enabled = False
        tbox3.Enabled = False
        tbox4.Enabled = False
        com1.Enabled = False
        com2.Enabled = False
        com3.Enabled = False
        com4.Enabled = False
        com5.Enabled = False
        com6.Enabled = False
        com7.Enabled = False
        com8.Enabled = False
        date1.Enabled = False
        date2.Enabled = False
        rt.Enabled = False
        btn_simpan.Enabled = False

    End Sub

    Sub buka()
        tbox1.Enabled = True
        tbox2.Enabled = True
        tbox3.Enabled = True
        tbox4.Enabled = True
        com1.Enabled = True
        com2.Enabled = True
        com3.Enabled = True
        com4.Enabled = True
        com5.Enabled = True
        com6.Enabled = True
        com7.Enabled = True
        com8.Enabled = True
        date1.Enabled = True
        date2.Enabled = True
        rt.Enabled = True
        btn_simpan.Enabled = True
        combo()
    End Sub

    Sub bersih()
        tbox1.Text = ""
        tbox2.Text = ""
        tbox3.Text = ""
        tbox4.Text = ""
        com1.Text = ""
        com2.Text = ""
        com3.Text = ""
        com4.Text = ""
        com5.Text = ""
        com6.Text = ""
        com7.Text = ""
        com8.Text = ""
        date1.Text = ""
        date2.Text = ""
        rt.Text = ""
    End Sub

    Sub combo()
        com1.Items.Add("Laki-Laki")
        com1.Items.Add("Perempuan")

        com2.Items.Add("A")
        com2.Items.Add("B")
        com2.Items.Add("AB")
        com2.Items.Add("O")

        com3.Items.Add("Islam")
        com3.Items.Add("Kristen")
        com3.Items.Add("Hindu")
        com3.Items.Add("Budha")
        com3.Items.Add("Konghucu")

        com4.Items.Add("SD")
        com4.Items.Add("SMP")
        com4.Items.Add("SMA/SLTA")
        com4.Items.Add("Kuliah")

        com5.Items.Add("Lulus")
        com5.Items.Add("Belum Lulus")

        com6.Items.Add("PNS")
        com6.Items.Add("Wiraswasta")
        com6.Items.Add("Wirausaha")
        com6.Items.Add("Petani")
        com6.Items.Add("Lainnya -silahkan isi-")

        com7.Items.Add("Belum menikah")
        com7.Items.Add("Menikah")

        com8.Items.Add("Indonesia")
        com8.Items.Add("Lainnya -isi sendiri-")

    End Sub

    Sub aturDGV()
        Try
            DataGrid_Penduduk.Columns(0).Width = 70
            DataGrid_Penduduk.Columns(1).Width = 100
            DataGrid_Penduduk.Columns(2).Width = 100
            DataGrid_Penduduk.Columns(3).Width = 100
            DataGrid_Penduduk.Columns(4).Width = 100
            DataGrid_Penduduk.Columns(5).Width = 100
            DataGrid_Penduduk.Columns(6).Width = 100
            DataGrid_Penduduk.Columns(7).Width = 100
            DataGrid_Penduduk.Columns(8).Width = 100
            DataGrid_Penduduk.Columns(9).Width = 100
            DataGrid_Penduduk.Columns(10).Width = 100
            DataGrid_Penduduk.Columns(11).Width = 100
            DataGrid_Penduduk.Columns(12).Width = 100
            DataGrid_Penduduk.Columns(13).Width = 100
            DataGrid_Penduduk.Columns(14).Width = 100

            DataGrid_Penduduk.Columns(0).HeaderText = "NIK"
            DataGrid_Penduduk.Columns(1).HeaderText = "NAMA"
            DataGrid_Penduduk.Columns(2).HeaderText = "Tempat Lahir"
            DataGrid_Penduduk.Columns(3).HeaderText = "tanggal lahir"
            DataGrid_Penduduk.Columns(4).HeaderText = "jenis kelamin"
            DataGrid_Penduduk.Columns(5).HeaderText = "golongan darah"
            DataGrid_Penduduk.Columns(6).HeaderText = "Alamat"
            DataGrid_Penduduk.Columns(7).HeaderText = "agama"
            DataGrid_Penduduk.Columns(8).HeaderText = "Pendidikan Terakhir"
            DataGrid_Penduduk.Columns(9).HeaderText = "Status Pendidikan"
            DataGrid_Penduduk.Columns(10).HeaderText = "Pekerjaan"
            DataGrid_Penduduk.Columns(11).HeaderText = "Status Kawin"
            DataGrid_Penduduk.Columns(12).HeaderText = "No Telpon"
            DataGrid_Penduduk.Columns(13).HeaderText = "Kewarganegaraan"
            DataGrid_Penduduk.Columns(14).HeaderText = "Tanggal Reg"

        Catch ex As Exception
        End Try
    End Sub

    Sub tampilGrid()
        Call koneksi()
        da = New MySqlDataAdapter("select nik, nama_lengkap, tmp_lahir, tgl_lahir, Jenis_Kelamin, gol_darah, alamat, agama, pendidikan_terakhir, status_pendidikan, kelmp_pekerjaan, status_perkawinan, no_tlpn, kewarganegaraan, tgl_reg from tabel_penduduk", conn)
        ds = New DataSet
        da.Fill(ds, "tabel_penduduk")
        DataGrid_Penduduk.DataSource = ds.Tables("tabel_penduduk")

    End Sub

    Sub hapus()
        Try
            Call koneksi()
            Dim str As String
            str = "delete from tabel_penduduk where nik = '" & tbox1.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data Siswa Berhasil Dihapus.")
        Catch ex As Exception
            MessageBox.Show("Data Siswa Gagal Dihapus.")
        End Try
    End Sub

    Private Sub btn_simpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_simpan.Click
        Call koneksi()
        
        Try
            Dim str As String
            str = "insert into tabel_penduduk (nik, nama_lengkap, tmp_lahir, tgl_lahir, Jenis_Kelamin, gol_darah, alamat, agama, pendidikan_terakhir, status_pendidikan, kelmp_pekerjaan, status_perkawinan, no_tlpn, kewarganegaraan, tgl_reg) values ('" & tbox1.Text & "','" & tbox2.Text & "','" & tbox3.Text & "','" & date1.Text & "','" & com1.Text & "','" & com2.Text & "','" & rt.Text & "','" & com3.Text & "','" & com4.Text & "','" & com5.Text & "','" & com6.Text & "','" & com7.Text & "','" & tbox4.Text & "','" & com8.Text & "','" & date2.Text & "')"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data Siswa Berhasil Disimpan.")
            Call aturDGV()
            DataGrid_Penduduk.Refresh()
            Call bersih()
        Catch ex As Exception
            MessageBox.Show("Data Siswa Gagal Disimpan")
        End Try
        update()
    End Sub

    Private Sub btn_tambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_tambah.Click
        buka()
        bersih()
    End Sub

    Private Sub btnkeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnkeluar.Click
        Me.Close()
    End Sub

    Private Sub btn_hapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_hapus.Click
        hapus()
    End Sub

    Private Sub DataGrid_Penduduk_CellMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGrid_Penduduk.CellMouseClick
        On Error Resume Next
        tbox1.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(0).Value
        tbox2.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(1).Value
        tbox3.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(2).Value
        date1.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(3).Value
        com1.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(4).Value
        com2.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(5).Value
        rt.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(6).Value
        com3.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(7).Value
        com4.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(8).Value
        com5.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(9).Value
        com6.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(10).Value
        com7.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(11).Value
        tbox4.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(12).Value
        com8.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(13).Value
        date2.Text = DataGrid_Penduduk.Rows(e.RowIndex).Cells(14).Value
    End Sub

    Private Sub btn_edit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_edit.Click
        edit()
    End Sub

    Sub edit()
        Try
            Call koneksi()
            Dim str As String
            str = "Update tabel_penduduk set nama_lengkap = '" & tbox2.Text & "', tmp_lahir = '" & tbox3.Text & "', tgl_lahir = '" & date1.Text & "', Jenis_Kelamin = '" & com1.Text & "', gol_darah = '" & com2.Text & "', alamat = '" & rt.Text & "', agama = '" & com3.Text & "', pendidikan_terakhir = '" & com4.Text & "', status_pendidikan = '" & com5.Text & "', kelmp_pekerjaan = '" & com6.Text & "', status_perkawinan = '" & com7.Text & "', no_tlpn = '" & tbox4.Text & "', kewarganegaraan = '" & com8.Text & "' , tgl_reg = '" & date2.Text & "' where NIK = '" & tbox1.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Update Data Siswa Berhasil Dilakukan.")
        Catch ex As Exception
            MessageBox.Show("Update data siswa gagal dilakukan")
        End Try
    End Sub


    Private Sub btn_ref_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ref.Click
        DataGrid_Penduduk.Refresh()
        bersih()
        Call tampilGrid()
        Call aturDGV()
        DataGrid_Penduduk.Refresh()
    End Sub
End Class
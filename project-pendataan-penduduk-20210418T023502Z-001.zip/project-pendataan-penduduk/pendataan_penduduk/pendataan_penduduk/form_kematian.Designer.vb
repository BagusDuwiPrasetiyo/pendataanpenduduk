﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_kematian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lbl_ygmenentukan = New System.Windows.Forms.Label()
        Me.lbl_sbbmeninggal = New System.Windows.Forms.Label()
        Me.lbl_tmptmeninggal = New System.Windows.Forms.Label()
        Me.lbl_hrmeninggal = New System.Windows.Forms.Label()
        Me.lbl_nik = New System.Windows.Forms.Label()
        Me.lbl_nama = New System.Windows.Forms.Label()
        Me.lbl_umur = New System.Windows.Forms.Label()
        Me.lbl_tglmeninggal = New System.Windows.Forms.Label()
        Me.DataGrid_kematian = New System.Windows.Forms.DataGridView()
        Me.judul = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        CType(Me.DataGrid_kematian, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_ygmenentukan
        '
        Me.lbl_ygmenentukan.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_ygmenentukan.AutoSize = True
        Me.lbl_ygmenentukan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ygmenentukan.Location = New System.Drawing.Point(160, 447)
        Me.lbl_ygmenentukan.Name = "lbl_ygmenentukan"
        Me.lbl_ygmenentukan.Size = New System.Drawing.Size(95, 13)
        Me.lbl_ygmenentukan.TabIndex = 81
        Me.lbl_ygmenentukan.Text = "Yang Menentukan"
        '
        'lbl_sbbmeninggal
        '
        Me.lbl_sbbmeninggal.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_sbbmeninggal.AutoSize = True
        Me.lbl_sbbmeninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sbbmeninggal.Location = New System.Drawing.Point(160, 398)
        Me.lbl_sbbmeninggal.Name = "lbl_sbbmeninggal"
        Me.lbl_sbbmeninggal.Size = New System.Drawing.Size(90, 13)
        Me.lbl_sbbmeninggal.TabIndex = 79
        Me.lbl_sbbmeninggal.Text = "Sebab Meninggal"
        '
        'lbl_tmptmeninggal
        '
        Me.lbl_tmptmeninggal.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_tmptmeninggal.AutoSize = True
        Me.lbl_tmptmeninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tmptmeninggal.Location = New System.Drawing.Point(160, 351)
        Me.lbl_tmptmeninggal.Name = "lbl_tmptmeninggal"
        Me.lbl_tmptmeninggal.Size = New System.Drawing.Size(95, 13)
        Me.lbl_tmptmeninggal.TabIndex = 77
        Me.lbl_tmptmeninggal.Text = "Tempat Meninggal"
        '
        'lbl_hrmeninggal
        '
        Me.lbl_hrmeninggal.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_hrmeninggal.AutoSize = True
        Me.lbl_hrmeninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hrmeninggal.Location = New System.Drawing.Point(163, 259)
        Me.lbl_hrmeninggal.Name = "lbl_hrmeninggal"
        Me.lbl_hrmeninggal.Size = New System.Drawing.Size(78, 13)
        Me.lbl_hrmeninggal.TabIndex = 75
        Me.lbl_hrmeninggal.Text = "Hari Meninggal"
        '
        'lbl_nik
        '
        Me.lbl_nik.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_nik.AutoSize = True
        Me.lbl_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nik.Location = New System.Drawing.Point(160, 118)
        Me.lbl_nik.Name = "lbl_nik"
        Me.lbl_nik.Size = New System.Drawing.Size(25, 13)
        Me.lbl_nik.TabIndex = 39
        Me.lbl_nik.Text = "NIK"
        '
        'lbl_nama
        '
        Me.lbl_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(160, 168)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(35, 13)
        Me.lbl_nama.TabIndex = 40
        Me.lbl_nama.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lbl_umur
        '
        Me.lbl_umur.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_umur.AutoSize = True
        Me.lbl_umur.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_umur.Location = New System.Drawing.Point(163, 215)
        Me.lbl_umur.Name = "lbl_umur"
        Me.lbl_umur.Size = New System.Drawing.Size(32, 13)
        Me.lbl_umur.TabIndex = 41
        Me.lbl_umur.Text = "Umur"
        '
        'lbl_tglmeninggal
        '
        Me.lbl_tglmeninggal.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_tglmeninggal.AutoSize = True
        Me.lbl_tglmeninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tglmeninggal.Location = New System.Drawing.Point(157, 304)
        Me.lbl_tglmeninggal.Name = "lbl_tglmeninggal"
        Me.lbl_tglmeninggal.Size = New System.Drawing.Size(98, 13)
        Me.lbl_tglmeninggal.TabIndex = 42
        Me.lbl_tglmeninggal.Text = "Tanggal Meninggal"
        '
        'DataGrid_kematian
        '
        Me.DataGrid_kematian.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid_kematian.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGrid_kematian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGrid_kematian.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGrid_kematian.Location = New System.Drawing.Point(12, 540)
        Me.DataGrid_kematian.Name = "DataGrid_kematian"
        Me.DataGrid_kematian.Size = New System.Drawing.Size(1330, 182)
        Me.DataGrid_kematian.TabIndex = 58
        '
        'judul
        '
        Me.judul.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(546, 10)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(253, 29)
        Me.judul.TabIndex = 59
        Me.judul.Text = "Pendataan Kematian"
        '
        'Button1
        '
        Me.Button1.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Button1.Location = New System.Drawing.Point(949, 114)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 71
        Me.Button1.Text = "Tambah"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Button2.Location = New System.Drawing.Point(949, 161)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 72
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Button3.Location = New System.Drawing.Point(949, 210)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 73
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Button4.Location = New System.Drawing.Point(949, 259)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 74
        Me.Button4.Text = "keluar"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(294, 110)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(449, 21)
        Me.ComboBox1.TabIndex = 82
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(294, 162)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(449, 20)
        Me.TextBox1.TabIndex = 83
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(294, 208)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(48, 20)
        Me.TextBox2.TabIndex = 84
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(294, 304)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(121, 20)
        Me.DateTimePicker1.TabIndex = 86
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(294, 259)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 87
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(294, 343)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 88
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(294, 398)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 89
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(294, 439)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 90
        '
        'form_kematian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1354, 733)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.lbl_ygmenentukan)
        Me.Controls.Add(Me.lbl_sbbmeninggal)
        Me.Controls.Add(Me.lbl_tmptmeninggal)
        Me.Controls.Add(Me.lbl_hrmeninggal)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.judul)
        Me.Controls.Add(Me.DataGrid_kematian)
        Me.Controls.Add(Me.lbl_tglmeninggal)
        Me.Controls.Add(Me.lbl_umur)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.lbl_nik)
        Me.Name = "form_kematian"
        Me.Text = "form_kematian"
        CType(Me.DataGrid_kematian, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_ygmenentukan As System.Windows.Forms.Label
    Friend WithEvents lbl_sbbmeninggal As System.Windows.Forms.Label
    Friend WithEvents lbl_tmptmeninggal As System.Windows.Forms.Label
    Friend WithEvents lbl_hrmeninggal As System.Windows.Forms.Label
    Friend WithEvents lbl_nik As System.Windows.Forms.Label
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
    Friend WithEvents lbl_umur As System.Windows.Forms.Label
    Friend WithEvents lbl_tglmeninggal As System.Windows.Forms.Label
    Friend WithEvents DataGrid_kematian As System.Windows.Forms.DataGridView
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_pindah
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_keluar = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_simpan = New System.Windows.Forms.Button()
        Me.btn_tambah = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.rtbox_ket = New System.Windows.Forms.RichTextBox()
        Me.lbl_ket = New System.Windows.Forms.Label()
        Me.rtbox_almttujuan = New System.Windows.Forms.RichTextBox()
        Me.lbl_almttujuan = New System.Windows.Forms.Label()
        Me.tgl_datang = New System.Windows.Forms.DateTimePicker()
        Me.lbl_pindah = New System.Windows.Forms.Label()
        Me.judul = New System.Windows.Forms.Label()
        Me.tbox_nama = New System.Windows.Forms.TextBox()
        Me.lbl_nama = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_keluar
        '
        Me.btn_keluar.Location = New System.Drawing.Point(524, 484)
        Me.btn_keluar.Name = "btn_keluar"
        Me.btn_keluar.Size = New System.Drawing.Size(75, 23)
        Me.btn_keluar.TabIndex = 92
        Me.btn_keluar.Text = "keluar"
        Me.btn_keluar.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(421, 484)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 91
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_simpan
        '
        Me.btn_simpan.Location = New System.Drawing.Point(307, 484)
        Me.btn_simpan.Name = "btn_simpan"
        Me.btn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.btn_simpan.TabIndex = 90
        Me.btn_simpan.Text = "Simpan"
        Me.btn_simpan.UseVisualStyleBackColor = True
        '
        'btn_tambah
        '
        Me.btn_tambah.Location = New System.Drawing.Point(197, 484)
        Me.btn_tambah.Name = "btn_tambah"
        Me.btn_tambah.Size = New System.Drawing.Size(75, 23)
        Me.btn_tambah.TabIndex = 89
        Me.btn_tambah.Text = "Tambah"
        Me.btn_tambah.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(793, 143)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(510, 569)
        Me.DataGridView1.TabIndex = 88
        '
        'rtbox_ket
        '
        Me.rtbox_ket.Location = New System.Drawing.Point(177, 314)
        Me.rtbox_ket.Name = "rtbox_ket"
        Me.rtbox_ket.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_ket.TabIndex = 87
        Me.rtbox_ket.Text = ""
        '
        'lbl_ket
        '
        Me.lbl_ket.AutoSize = True
        Me.lbl_ket.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ket.Location = New System.Drawing.Point(61, 317)
        Me.lbl_ket.Name = "lbl_ket"
        Me.lbl_ket.Size = New System.Drawing.Size(62, 13)
        Me.lbl_ket.TabIndex = 86
        Me.lbl_ket.Text = "Keterangan"
        '
        'rtbox_almttujuan
        '
        Me.rtbox_almttujuan.Location = New System.Drawing.Point(177, 241)
        Me.rtbox_almttujuan.Name = "rtbox_almttujuan"
        Me.rtbox_almttujuan.Size = New System.Drawing.Size(448, 41)
        Me.rtbox_almttujuan.TabIndex = 85
        Me.rtbox_almttujuan.Text = ""
        '
        'lbl_almttujuan
        '
        Me.lbl_almttujuan.AutoSize = True
        Me.lbl_almttujuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_almttujuan.Location = New System.Drawing.Point(61, 244)
        Me.lbl_almttujuan.Name = "lbl_almttujuan"
        Me.lbl_almttujuan.Size = New System.Drawing.Size(75, 13)
        Me.lbl_almttujuan.TabIndex = 84
        Me.lbl_almttujuan.Text = "Alamat Tujuan"
        '
        'tgl_datang
        '
        Me.tgl_datang.Location = New System.Drawing.Point(177, 190)
        Me.tgl_datang.Name = "tgl_datang"
        Me.tgl_datang.Size = New System.Drawing.Size(448, 20)
        Me.tgl_datang.TabIndex = 81
        '
        'lbl_pindah
        '
        Me.lbl_pindah.AutoSize = True
        Me.lbl_pindah.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pindah.Location = New System.Drawing.Point(61, 196)
        Me.lbl_pindah.Name = "lbl_pindah"
        Me.lbl_pindah.Size = New System.Drawing.Size(82, 13)
        Me.lbl_pindah.TabIndex = 80
        Me.lbl_pindah.Text = "Tanggal Pindah"
        '
        'judul
        '
        Me.judul.AutoSize = True
        Me.judul.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul.Location = New System.Drawing.Point(609, 29)
        Me.judul.Name = "judul"
        Me.judul.Size = New System.Drawing.Size(225, 29)
        Me.judul.TabIndex = 79
        Me.judul.Text = "Pendataan Pindah"
        '
        'tbox_nama
        '
        Me.tbox_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbox_nama.Location = New System.Drawing.Point(177, 143)
        Me.tbox_nama.Name = "tbox_nama"
        Me.tbox_nama.Size = New System.Drawing.Size(448, 20)
        Me.tbox_nama.TabIndex = 94
        '
        'lbl_nama
        '
        Me.lbl_nama.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nama.Location = New System.Drawing.Point(60, 150)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(35, 13)
        Me.lbl_nama.TabIndex = 93
        Me.lbl_nama.Text = "Nama" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'form_pindah
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.tbox_nama)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.btn_keluar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btn_simpan)
        Me.Controls.Add(Me.btn_tambah)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.rtbox_ket)
        Me.Controls.Add(Me.lbl_ket)
        Me.Controls.Add(Me.rtbox_almttujuan)
        Me.Controls.Add(Me.lbl_almttujuan)
        Me.Controls.Add(Me.tgl_datang)
        Me.Controls.Add(Me.lbl_pindah)
        Me.Controls.Add(Me.judul)
        Me.Name = "form_pindah"
        Me.Text = "form_pindah"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_keluar As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btn_simpan As System.Windows.Forms.Button
    Friend WithEvents btn_tambah As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents rtbox_ket As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_ket As System.Windows.Forms.Label
    Friend WithEvents rtbox_almttujuan As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_almttujuan As System.Windows.Forms.Label
    Friend WithEvents tgl_datang As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_pindah As System.Windows.Forms.Label
    Friend WithEvents judul As System.Windows.Forms.Label
    Friend WithEvents tbox_nama As System.Windows.Forms.TextBox
    Friend WithEvents lbl_nama As System.Windows.Forms.Label
End Class
